﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace POC.GitHubSearch.Services.App_Code
{
    public static class Constants
    {
        public static class Origins
        {
            //public static string Current
            //{
            //    get { return ConfigurationManager.AppSettings["CURRENT_ORIGIN"]; }
            //}

            public const string GitHubSearchWeb = "https://localhost:44390";
            
        }
    }
}